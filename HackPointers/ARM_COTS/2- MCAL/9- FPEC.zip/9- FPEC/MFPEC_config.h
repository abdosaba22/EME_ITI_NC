/* ******************************************************** */
/* Author      	:	 Abd-alrahman Amin						*/
/* SWC         	:	 Flash Program and erase controller		*/
/* Layer       	:	 MCAL              						*/
/* MCu     		:	 stm32f103         						*/
/* Version     	:	 1.0               						*/
/* Date        	:	 September 23, 2023						*/
/* Last Edit   	:	 N/A 									*/
/* ******************************************************** */

#ifndef _MFPEC_CONFIG_H_
#define _MFPEC_CONFIG_H_


#endif